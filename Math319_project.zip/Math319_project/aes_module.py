from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import json

def generate_key_iv():
    key = get_random_bytes(32)
    iv = get_random_bytes(16)
    return key, iv

def pad(data):
    pad_len = 16 - len(data) % 16
    return data + bytes([pad_len]) * pad_len

def unpad(data):
    pad_len = data[-1]
    return data[:-pad_len]

def encrypt_file(input_file, output_file, key, iv):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    with open(input_file, 'rb') as f:
        plaintext = f.read()
    plaintext_padded = pad(plaintext)
    ciphertext = cipher.encrypt(plaintext_padded)
    with open(output_file, 'wb') as f:
        f.write(ciphertext)
    print(f"File encrypted: {output_file}")

def decrypt_file(input_file, output_file, key, iv):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    with open(input_file, 'rb') as f:
        ciphertext = f.read()
    plaintext_padded = cipher.decrypt(ciphertext)
    plaintext = unpad(plaintext_padded)
    with open(output_file, 'wb') as f:
        f.write(plaintext)
    print(f"File decrypted: {output_file}")

def save_key_iv(key, iv):
    data = {'key': key.hex(), 'iv': iv.hex()}
    with open('key_iv.json', 'w') as f:
        json.dump(data, f)
    print("Key and IV saved in key_iv.json")

if __name__ == "__main__":
    key, iv = generate_key_iv()
    save_key_iv(key, iv)
    encrypt_file('example.txt', 'example_encrypted.bin', key, iv)
    decrypt_file('example_encrypted.bin', 'example_decrypted.txt', key, iv)
