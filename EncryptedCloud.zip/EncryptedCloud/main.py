# main.py

from encryption import encrypt_file, decrypt_file
from cloud import upload_to_drive, download_from_drive

def main():
    print("=== Cloud Backup with AES Encryption ===")

    # 1) Encrypt the file
    encrypt_file("example.txt", "encrypted.bin")

    # 2) Upload to Google Drive
    file_id = upload_to_drive("encrypted.bin")

    # 3) Download it back
    download_from_drive(file_id, "downloaded.bin")

    # 4) Decrypt the downloaded file
    decrypt_file("downloaded.bin", "recovered.txt")

    print("\nAll steps completed successfully!")

if __name__ == "__main__":
    main()