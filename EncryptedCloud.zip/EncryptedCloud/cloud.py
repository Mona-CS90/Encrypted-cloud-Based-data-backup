import shutil
import os

CLOUD_FOLDER = "cloud_backup"

# إنشاء مجلد Cloud إذا لم يكن موجود
if not os.path.exists(CLOUD_FOLDER):
    os.makedirs(CLOUD_FOLDER)

def upload_to_drive(file_path):
    dest_path = os.path.join(CLOUD_FOLDER, os.path.basename(file_path))
    shutil.copyfile(file_path, dest_path)
    print(f"[+] Uploaded to cloud folder: {dest_path}")
    return dest_path  # نستخدم path كـ "file_id" وهمي

def download_from_drive(file_id, output_path):
    shutil.copyfile(file_id, output_path)
    print(f"[+] Downloaded from cloud folder → {output_path}")