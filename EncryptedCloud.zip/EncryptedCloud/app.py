import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image
import os
import json
from Crypto.Cipher import AES


# ------------------------- Encryption ------------------------
def load_key_iv():
    with open("key_iv.json", "r") as f:
        data = json.load(f)
    key = bytes.fromhex(data["key"])
    iv = bytes.fromhex(data["iv"])
    return key, iv

def pad(data):
    pad_len = 16 - len(data) % 16
    return data + bytes([pad_len]) * pad_len

def unpad(data):
    pad_len = data[-1]
    return data[:-pad_len]

def encrypt_file(input_file, output_file):
    key, iv = load_key_iv()
    cipher = AES.new(key, AES.MODE_CBC, iv)

    with open(input_file, 'rb') as f:
        plaintext = f.read()

    plaintext_padded = pad(plaintext)
    ciphertext = cipher.encrypt(plaintext_padded)

    with open(output_file, 'wb') as f:
        f.write(ciphertext)

def decrypt_file(input_file, output_file):
    key, iv = load_key_iv()
    cipher = AES.new(key, AES.MODE_CBC, iv)

    with open(input_file, 'rb') as f:
        ciphertext = f.read()

    plaintext_padded = cipher.decrypt(ciphertext)
    plaintext = unpad(plaintext_padded)

    with open(output_file, 'wb') as f:
        f.write(plaintext)


# ------------------------- Users ------------------------
def load_users():
    if not os.path.exists("users.json"):
        return {}
    with open("users.json", "r") as f:
        return json.load(f)

def save_users(users):
    with open("users.json", "w") as f:
        json.dump(users, f, indent=4)


# ------------------------- App ------------------------
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

app = ctk.CTk()
app.title("Encrypted Cloud Backup")
app.geometry("550x480")

current_user = ""

# ----------- FUNCTIONS TO SWITCH BETWEEN PAGES -----------
def show_login():
    cloud_frame.pack_forget()
    home_frame.pack_forget()
    login_frame.pack(fill="both", expand=True)

def show_home():
    login_frame.pack_forget()
    cloud_frame.pack_forget()
    home_frame.pack(fill="both", expand=True)

def show_cloud_page():
    load_cloud_files()
    login_frame.pack_forget()
    home_frame.pack_forget()
    cloud_frame.pack(fill="both", expand=True)


# ------------------------- LOGIN PAGE ------------------------
login_frame = ctk.CTkFrame(app)

logo_image = None
if os.path.exists("logo.png"):
    logo_image = ctk.CTkImage(light_image=Image.open("logo.png"),
                              dark_image=Image.open("logo.png"),
                              size=(120,120))

logo_label = ctk.CTkLabel(login_frame, image=logo_image, text="")
logo_label.pack(pady=10)

title = ctk.CTkLabel(login_frame, text="Encrypted Cloud Backup", font=("Arial", 20, "bold"))
title.pack(pady=15)

username_entry = ctk.CTkEntry(login_frame, placeholder_text="Username", width=260)
username_entry.pack(pady=10)

password_entry = ctk.CTkEntry(login_frame, placeholder_text="Password", show="*", width=260)
password_entry.pack(pady=10)

def login():
    users = load_users()
    username = username_entry.get()
    password = password_entry.get()

    if username in users and users[username] == password:
        global current_user
        current_user = username
        welcome_label.configure(text=f"Welcome, {current_user}")
        show_home()
    else:
        messagebox.showerror("Error", "Wrong username or password")

def register():
    users = load_users()
    username = username_entry.get()
    password = password_entry.get()

    if not username or not password:
        messagebox.showerror("Error", "Please fill all fields")
        return

    if username in users:
        messagebox.showerror("Error", "Username already exists")
    else:
        users[username] = password
        save_users(users)
        messagebox.showinfo("Success", "Account created, please login")

login_btn = ctk.CTkButton(login_frame, text="Login", width=200, command=login)
login_btn.pack(pady=10)

register_btn = ctk.CTkButton(login_frame, text="Create Account", width=200, command=register)
register_btn.pack(pady=10)# ------------------------- HOME PAGE ------------------------
home_frame = ctk.CTkFrame(app)

welcome_label = ctk.CTkLabel(home_frame, text="", font=("Arial", 18, "bold"))
welcome_label.pack(pady=20)

def upload_file():
    file_path = filedialog.askopenfilename()
    if file_path:
        user_folder = f"cloud/{current_user}"
        os.makedirs(user_folder, exist_ok=True)

        file_name = os.path.basename(file_path)
        encrypted_path = f"{user_folder}/{file_name}.enc"

        encrypt_file(file_path, encrypted_path)
        messagebox.showinfo("Success", "File encrypted & uploaded")

upload_btn = ctk.CTkButton(home_frame, text="Upload File", width=260, height=40, command=upload_file)
upload_btn.pack(pady=10)

go_cloud_page_btn = ctk.CTkButton(home_frame, text="My Cloud Files", width=260, height=40, command=show_cloud_page)
go_cloud_page_btn.pack(pady=10)

logout_btn = ctk.CTkButton(home_frame, text="Logout", width=200, command=show_login)
logout_btn.pack(pady=20)



# ------------------------- CLOUD FILE LIST PAGE ------------------------
cloud_frame = ctk.CTkFrame(app)

cloud_title = ctk.CTkLabel(cloud_frame, text="Your Cloud Files", font=("Arial", 18, "bold"))
cloud_title.pack(pady=15)

file_list_box = ctk.CTkTextbox(cloud_frame, width=450, height=230)
file_list_box.pack(pady=10)

def load_cloud_files():
    file_list_box.delete("1.0", "end")
    folder = f"cloud/{current_user}"

    if not os.path.exists(folder):
        file_list_box.insert("end", "No files found.\n")
        return

    files = os.listdir(folder)
    if not files:
        file_list_box.insert("end", "Cloud is empty.\n")
        return

    for f in files:
        file_list_box.insert("end", f + "\n")

def download_from_cloud():
    folder = f"cloud/{current_user}"
    if not os.path.exists(folder):
        return

    files = os.listdir(folder)
    if not files:
        return

    # popup
    popup = ctk.CTkToplevel(app)
    popup.title("Download File")
    popup.geometry("300x300")

    for file in files:
        btn = ctk.CTkButton(
            popup,
            text=file,
            command=lambda f=file: decrypt_selected(f, popup)
        )
        btn.pack(pady=5)

def decrypt_selected(file, popup):
    source = f"cloud/{current_user}/{file}"
    dest_dir = filedialog.askdirectory()

    if dest_dir:
        output_path = dest_dir + "/" + file.replace(".enc", "")
        decrypt_file(source, output_path)
        messagebox.showinfo("Success", "File downloaded & decrypted")
        popup.destroy()

download_btn = ctk.CTkButton(cloud_frame, text="Download File", width=250, command=download_from_cloud)
download_btn.pack(pady=10)

back_btn = ctk.CTkButton(cloud_frame, text="Back to Home", width=250, command=show_home)
back_btn.pack(pady=10)



# Start with login page
show_login()

app.mainloop()