# encryption.py

from Crypto.Cipher import AES
import json

# -----------------------------
# Load Key & IV from JSON file
# -----------------------------
def load_key_iv():
    with open("key_iv.json", "r") as f:
        data = json.load(f)
    key = bytes.fromhex(data["key"])
    iv = bytes.fromhex(data["iv"])
    return key, iv

# -----------------------------
# Padding Functions
# -----------------------------
def pad(data):
    pad_len = 16 - len(data) % 16
    return data + bytes([pad_len]) * pad_len

def unpad(data):
    pad_len = data[-1]
    return data[:-pad_len]

# -----------------------------
# AES Encryption
# -----------------------------
def encrypt_file(input_file, output_file):
    key, iv = load_key_iv()
    cipher = AES.new(key, AES.MODE_CBC, iv)

    with open(input_file, 'rb') as f:
        plaintext = f.read()

    plaintext_padded = pad(plaintext)
    ciphertext = cipher.encrypt(plaintext_padded)

    with open(output_file, 'wb') as f:
        f.write(ciphertext)

    print(f"[+] File encrypted → {output_file}")

# -----------------------------
# AES Decryption
# -----------------------------
def decrypt_file(input_file, output_file):
    key, iv = load_key_iv()
    cipher = AES.new(key, AES.MODE_CBC, iv)

    with open(input_file, 'rb') as f:
        ciphertext = f.read()

    plaintext_padded = cipher.decrypt(ciphertext)
    plaintext = unpad(plaintext_padded)

    with open(output_file, 'wb') as f:
        f.write(plaintext)

    print(f"[+] File decrypted → {output_file}")